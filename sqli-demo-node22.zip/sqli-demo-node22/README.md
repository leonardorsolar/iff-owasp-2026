# 💉 SQL Injection — Demo Prática

Dois servidores Node.js + Express + SQLite para ver o ataque na prática.

---

## 🚀 Como rodar

```bash
npm install

# Terminal 1 — servidor VULNERÁVEL (porta 3000)
node --experimental-sqlite vulneravel.js

# Terminal 2 — servidor SEGURO (porta 3001)
node --experimental-sqlite seguro.js
```

---

## 🔴 Servidor VULNERÁVEL — porta 3000

### ✅ 1. Login normal (funciona)

```bash
curl -s -X POST http://localhost:3000/login \
  -H "Content-Type: application/json" \
  -d '{"username":"joao","password":"joao2024"}'
```

**Resposta:**
```json
{
  "ok": true,
  "mensagem": "Logado como: joao [user]"
}
```

**SQL executado no servidor:**
```sql
SELECT * FROM usuarios WHERE username = 'joao' AND password = 'joao2024'
```

---

### ❌ 2. Senha errada (bloqueado)

```bash
curl -s -X POST http://localhost:3000/login \
  -H "Content-Type: application/json" \
  -d '{"username":"joao","password":"errada"}'
```

**Resposta:**
```json
{ "ok": false, "mensagem": "Usuário ou senha inválidos" }
```

---

### 💥 3. ATAQUE — bypass com `OR 1=1`

**Não sabe nenhuma senha, mas entra como admin e vaza TODOS os usuários:**

```bash
curl -s -X POST http://localhost:3000/login \
  -H "Content-Type: application/json" \
  -d '{"username":"'\'' OR 1=1--","password":"x"}'
```

**Resposta — TODOS os usuários vazados:**
```json
{
  "ok": true,
  "mensagem": "Logado como: admin [admin]",
  "atencao": "3 registro(s) retornado(s)!",
  "dados_vazados": [
    { "id": 1, "username": "admin", "password": "segredo123", "role": "admin" },
    { "id": 2, "username": "joao",  "password": "joao2024",   "role": "user"  },
    { "id": 3, "username": "maria", "password": "maria@pass", "role": "user"  }
  ]
}
```

**SQL executado no servidor (manipulado pelo atacante):**
```sql
SELECT * FROM usuarios WHERE username = '' OR 1=1-- ' AND password = 'x'
--                                            ^^^^^^^^
--                           sempre verdadeiro! AND password... foi comentado
```

---

### 💥 4. ATAQUE — entrar como admin sem saber a senha

```bash
curl -s -X POST http://localhost:3000/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin'\''--","password":"qualquer"}'
```

**Resposta:**
```json
{
  "ok": true,
  "mensagem": "Logado como: admin [admin]",
  "dados_vazados": [{ "id": 1, "username": "admin", "password": "segredo123", "role": "admin" }]
}
```

**SQL executado no servidor:**
```sql
SELECT * FROM usuarios WHERE username = 'admin'-- ' AND password = 'qualquer'
--                                             ^^
--                              tudo depois foi comentado — senha ignorada!
```

---

## 🟢 Servidor SEGURO — porta 3001

### ✅ Login normal (funciona igual)

```bash
curl -s -X POST http://localhost:3001/login \
  -H "Content-Type: application/json" \
  -d '{"username":"joao","password":"joao2024"}'
```

**Resposta:**
```json
{ "ok": true, "mensagem": "Logado como: joao [user]" }
```

---

### 🛡️ Ataque bloqueado — mesmo payload, zero efeito

```bash
curl -s -X POST http://localhost:3001/login \
  -H "Content-Type: application/json" \
  -d '{"username":"'\'' OR 1=1--","password":"x"}'
```

**Resposta:**
```json
{ "ok": false, "mensagem": "Usuário ou senha inválidos" }
```

**Por quê funciona?** O servidor usa `?` como placeholder:
```sql
SELECT * FROM usuarios WHERE username = ? AND password = ?
--                                       ^               ^
--               o banco trata os valores como TEXTO PURO, nunca como SQL
```

O payload `' OR 1=1--` vira literalmente a string `' OR 1=1--`
procurada no campo username — nenhum usuário tem esse nome, retorna vazio.

---

## 📊 Resumo

| Payload                | Vulnerável 🔴 | Seguro 🟢 |
|------------------------|--------------|-----------|
| Login correto          | ✅ Entra      | ✅ Entra   |
| Senha errada           | ❌ Bloqueado  | ❌ Bloqueado|
| `' OR 1=1--`           | 💥 TODOS vazam| ❌ Bloqueado|
| `admin'--`             | 💥 Admin sem senha | ❌ Bloqueado |

## 🔑 A diferença no código

```js
// ❌ VULNERÁVEL — string interpolada
const sql = `SELECT * FROM usuarios WHERE username = '${username}' AND password = '${password}'`
db.prepare(sql).all()

// ✅ SEGURO — prepared statement
const sql = `SELECT * FROM usuarios WHERE username = ? AND password = ?`
db.prepare(sql).all(username, password)
```
