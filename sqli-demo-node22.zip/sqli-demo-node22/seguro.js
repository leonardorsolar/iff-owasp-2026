// =====================================================
//  SERVIDOR SEGURO — Prepared Statements
//  node --experimental-sqlite seguro.js
// =====================================================
const express = require('express')
const { DatabaseSync } = require('node:sqlite')

const app = express()
app.use(express.json())

// --- Banco SQLite em memória ---
const db = new DatabaseSync(':memory:')
db.exec(`
  CREATE TABLE usuarios (id INTEGER PRIMARY KEY, username TEXT, password TEXT, role TEXT);
  INSERT INTO usuarios VALUES (1, 'admin', 'segredo123', 'admin');
  INSERT INTO usuarios VALUES (2, 'joao',  'joao2024',   'user');
  INSERT INTO usuarios VALUES (3, 'maria', 'maria@pass', 'user');
`)

// =====================================================
//  POST /login  ← SEGURO
// =====================================================
app.post('/login', (req, res) => {
  const { username, password } = req.body

  // ✅ Prepared Statement — ? são substituídos com segurança
  const sql = `SELECT * FROM usuarios WHERE username = ? AND password = ?`

  console.log('\n🟢 SQL (template): ' + sql)
  console.log('   Parâmetros:     ' + JSON.stringify([username, password]))

  const resultado = db.prepare(sql).all(username, password)

  if (resultado.length > 0) {
    res.json({
      ok: true,
      mensagem: `Logado como: ${resultado[0].username} [${resultado[0].role}]`
    })
  } else {
    res.status(401).json({ ok: false, mensagem: 'Usuário ou senha inválidos' })
  }
})

app.listen(3001, () => {
  console.log('🟢 Servidor SEGURO em http://localhost:3001\n')
})
